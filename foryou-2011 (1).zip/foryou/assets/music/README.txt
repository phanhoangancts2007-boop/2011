Bỏ file nhạc vào đây với tên nhac.mp3 (hoặc sửa đường dẫn trong config.js).
Dùng nhạc bạn có quyền sử dụng. Nếu không có file, trang sẽ tự phát giai điệu hộp nhạc nhẹ.
