Bỏ 10 ảnh vào thư mục này, đặt tên 01.jpg ... 10.jpg (hoặc sửa tên trong config.js).
Nên thu nhỏ mỗi ảnh về cạnh dài khoảng 1600px, dưới 500KB để trang mở nhanh trên điện thoại.
